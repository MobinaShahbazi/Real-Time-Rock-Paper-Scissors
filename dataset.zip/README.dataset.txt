# Reyhaneh-Mahdis-Mobina-Kowsar > 2025-01-27 6:14pm
https://universe.roboflow.com/reyhane2525/reyhaneh-mahdis-mobina-kowsar

Provided by a Roboflow user
License: CC BY 4.0

